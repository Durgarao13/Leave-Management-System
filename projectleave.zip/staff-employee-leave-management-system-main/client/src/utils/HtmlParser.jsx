//External Lib Import
import parse from "html-react-parser";

const HtmlParser = (html) => {
  return parse(html);
};

export default HtmlParser;
